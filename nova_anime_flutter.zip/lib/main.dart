import 'package:flutter/material.dart';

void main() {
  runApp(const NovaAnimeApp());
}

class NovaAnimeApp extends StatelessWidget {
  const NovaAnimeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nova Anime',
      theme: ThemeData.dark(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nova Anime'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'مرحباً بك في Nova Anime',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text('مشاهدة الأنمي وإدارة الباقة من مكان واحد.'),
          const SizedBox(height: 24),
          Card(
            child: ListTile(
              leading: const Icon(Icons.play_circle_fill),
              title: const Text('ابدأ المشاهدة'),
              subtitle: const Text('اختار الأنمي والحلقة المفضلة لديك.'),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.workspace_premium),
              title: const Text('الباقات'),
              subtitle: const Text('عرض الباقات وخيارات الدفع.'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PlansScreen()),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PlansScreen extends StatelessWidget {
  const PlansScreen({super.key});

  static const walletNumber = '01205152794';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الباقات والدفع')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'طرق الدفع',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'للدفع اليدوي، استخدم وسيلة الدفع التي يوفرها صاحب التطبيق، '
                'ثم أرسل رقم العملية/إثبات الدفع للدعم لتأكيد الاشتراك.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.account_balance_wallet),
              title: const Text('المحفظة'),
              subtitle: const Text(walletNumber),
            ),
          ),
          const SizedBox(height: 8),
          const Card(
            child: ListTile(
              leading: Icon(Icons.account_balance),
              title: Text('حوالة بنكية'),
              subtitle: Text(
                'يمكن قبول التحويل البنكي بعد التحقق اليدوي من العملية.',
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'مهم: لا يتم تفعيل أي باقة تلقائياً بمجرد إدخال بيانات الدفع؛ '
            'يجب التحقق من العملية قبل التفعيل.',
            style: TextStyle(color: Colors.orangeAccent),
          ),
        ],
      ),
    );
  }
}
